<header class="header">
				<div class="logo">
					<img src="photos/ENTETE01.jpg">
					<h2>Validation Etudiant</h2>
				</div>
				
				<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="slider/engine1/style.css" />
<script type="text/javascript" src="slider/engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
				
			<nav>
				<div class="nav">
					<ul>
						<li><a href="#" class="menu-icon">Ξ</a></li>
						<li><a href="index.php">Acceuil</a></li>
						<li><a href="authentifier.php">Valider</a></li>
						<li><a href="imprimer.html">Imprimer</a></li>
						<li><a href="#">Aide</a></li>
					</ul>
				</div>
			</nav>
		</header>