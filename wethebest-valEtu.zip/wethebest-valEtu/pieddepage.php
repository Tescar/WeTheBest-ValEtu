<footer class="conteneur-fluid">
						<h5>Universite INUKA</h5>
					<p>Copyright © Tous droits reserves ® Developpe par We the Best </p>
				</footer>