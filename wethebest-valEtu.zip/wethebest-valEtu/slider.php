	<div id="slider">
					
			<h2>Explication</h2>
		<div class="banner">
			<!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="slider/data1/images/a6561.jpg" alt="A6561" title="A6561" id="wows1_0"/></li>
		<li><img src="slider/data1/images/entete.jpg" alt="ENTETE" title="ENTETE" id="wows1_1"/></li>
		<li><img src="slider/data1/images/entremetsamandesgriottines640.jpg" alt="entremets-amandes-griottines-640" title="entremets-amandes-griottines-640" id="wows1_2"/></li>
		<li><img src="slider/data1/images/fiche_depot.jpg" alt="fiche_depot" title="fiche_depot" id="wows1_3"/></li>
		<li><img src="slider/data1/images/saliere_et_poivriere.jpg" alt="saliere et poivriere" title="saliere et poivriere" id="wows1_4"/></li>
		<li><img src="slider/data1/images/verre_a_eau.jpg" alt="verre a eau" title="verre a eau" id="wows1_5"/></li>
		<li><a href="http://wowslider.net"><img src="slider/data1/images/verreavinblancmaturo49clvinothequeluigibormioli.jpg" alt="bootstrap slider" title="verre-a-vin-blanc-maturo-49cl-vinotheque-luigi-bormioli" id="wows1_6"/></a></li>
		<li><img src="slider/data1/images/vin_rouge.jpg" alt="vin rouge" title="vin rouge" id="wows1_7"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="A6561"><span><img src="slider/data1/tooltips/a6561.jpg" alt="A6561"/>1</span></a>
		<a href="#" title="ENTETE"><span><img src="slider/data1/tooltips/entete.jpg" alt="ENTETE"/>2</span></a>
		<a href="#" title="entremets-amandes-griottines-640"><span><img src="slider/data1/tooltips/entremetsamandesgriottines640.jpg" alt="entremets-amandes-griottines-640"/>3</span></a>
		<a href="#" title="fiche_depot"><span><img src="slider/data1/tooltips/fiche_depot.jpg" alt="fiche_depot"/>4</span></a>
		<a href="#" title="saliere et poivriere"><span><img src="slider/data1/tooltips/saliere_et_poivriere.jpg" alt="saliere et poivriere"/>5</span></a>
		<a href="#" title="verre a eau"><span><img src="slider/data1/tooltips/verre_a_eau.jpg" alt="verre a eau"/>6</span></a>
		<a href="#" title="verre-a-vin-blanc-maturo-49cl-vinotheque-luigi-bormioli"><span><img src="slider/data1/tooltips/verreavinblancmaturo49clvinothequeluigibormioli.jpg" alt="verre-a-vin-blanc-maturo-49cl-vinotheque-luigi-bormioli"/>7</span></a>
		<a href="#" title="vin rouge"><span><img src="slider/data1/tooltips/vin_rouge.jpg" alt="vin rouge"/>8</span></a>
	</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">html slideshow</a> by WOWSlider.com v8.8</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="slider/engine1/wowslider.js"></script>
<script type="text/javascript" src="slider/engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->
		</div>
					
	</div>